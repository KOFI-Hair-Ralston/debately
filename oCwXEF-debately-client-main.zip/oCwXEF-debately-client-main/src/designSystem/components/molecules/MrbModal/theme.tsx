export interface MrbModalTheme {
  border?: string
  boxShadow?: string
  background?: string
}
