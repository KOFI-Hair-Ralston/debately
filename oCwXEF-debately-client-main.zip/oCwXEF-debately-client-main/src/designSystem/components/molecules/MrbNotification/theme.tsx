export interface MrbNotificationTheme {
  border: string
  background: string
  boxShadow: string

  blur: {
    boxShadow: string
  }
}
