export interface MrbNavbarDropdownTheme {
  background: string
  border: string
}
