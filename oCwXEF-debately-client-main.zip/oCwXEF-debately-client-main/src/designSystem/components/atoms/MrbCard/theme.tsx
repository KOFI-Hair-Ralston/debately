export interface MrbCardTheme {
  background: string
  border: string
  boxShadow?: string
  hover?: {
    background?: string
  }
}
