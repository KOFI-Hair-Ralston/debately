export interface MrbTooltipTheme {
  color?: string
  background?: string
  border?: string
  boxShadow?: string
  borderRadius?: string
  textSize?: string
}
