export interface MrbNavbarTheme {
  background: string
  borderBottom: string
}
export interface MrbLeftNavbarTheme {
  background: string
  borderRight: string
  width: string
}
