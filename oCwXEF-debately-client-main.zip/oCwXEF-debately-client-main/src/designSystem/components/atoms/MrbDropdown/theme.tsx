export interface MrbDropdownTheme {
  background?: string
  border?: string
}
