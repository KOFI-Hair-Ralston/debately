import { ThemeDark } from './theme.dark'
import { ThemeType } from './type'

export const Theme: ThemeType = ThemeDark
