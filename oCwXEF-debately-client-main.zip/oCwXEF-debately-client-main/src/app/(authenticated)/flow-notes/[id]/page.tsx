'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbLoader, MrbRow, MrbForm } from '@/designSystem'
import { Note, NoteApi } from '@/domain/note'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function EditNotePage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [item, setItem] = useState<Note | null>(null)

  useEffect(() => {
    const fetchNote = async () => {
      if (params.id) {
        try {
          const note = await NoteApi.findOne(params.id)
          setItem(note)
          setLoading(false)
        } catch (error) {
          toast.error('Error fetching note')
          setLoading(false)
        }
      }
    }

    fetchNote()
  }, [params.id])

  const handleSubmit = async (values: any) => {
    if (item) {
      try {
        await NoteApi.updateOne(item.id, { content: values.content })
        toast.success('Note updated successfully')
        router.push('/flow-notes')
      } catch (error) {
        toast.error('Error updating note')
      }
    }
  }

  const handleCancel = () => {
    router.push('/flow-notes')
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && item && (
        <MrbCard>
          <MrbCard.Body>
            <MrbForm
              defaultValues={{ content: item.content }}
              onSubmit={handleSubmit}
              inputs={[
                {
                  key: 'content',
                  type: 'textarea',
                  label: 'Content',
                },
              ]}
            >
              <MrbButton type="submit" variant="primary" size="medium">
                Save
              </MrbButton>
            </MrbForm>
          </MrbCard.Body>
          <MrbCard.Footer>
            <MrbRow horizontal="right" gap={1}>
              <MrbButton onClick={handleCancel} variant="default" size="medium">
                Cancel
              </MrbButton>
            </MrbRow>
          </MrbCard.Footer>
        </MrbCard>
      )}
    </PageLayout>
  )
}