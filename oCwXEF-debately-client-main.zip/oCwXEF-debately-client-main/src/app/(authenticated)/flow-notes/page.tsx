'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbButton, MrbCol, MrbEmptyState, MrbList, MrbLoader, MrbRow, MrbTypography } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Note, NoteApi } from '@/domain/note'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function FlowNotesPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [items, setItems] = useState<Note[]>([])

  useEffect(() => {
    if (userId) {
      NoteApi.findManyByUserId(userId, { includes: ['column'] })
        .then((notes) => {
          setItems(notes)
          setLoading(false)
        })
        .catch((error) => {
          toast.error('Failed to fetch notes')
          setLoading(false)
        })
    }
  }, [userId])

  const handleAddNote = (columnId: string) => {
    router.push(`/flow-notes/new?columnId=${columnId}`)
  }

  const handleEditNote = (noteId: string) => {
    router.push(`/flow-notes/${noteId}`)
  }

  const handleDeleteNote = async (noteId: string) => {
    try {
      await NoteApi.deleteOne(noteId)
      setItems(items.filter((note) => note.id !== noteId))
      toast.success('Note deleted successfully')
    } catch (error) {
      toast.error('Failed to delete note')
    }
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          {items.length === 0 && (
            <MrbEmptyState>
              There are no items to display.
              <MrbButton onClick={() => router.push('/flow-notes/new')}>
                Add Note
              </MrbButton>
            </MrbEmptyState>
          )}
          <MrbList divider={false}>
            {items.map((item) => (
              <MrbList.Item key={item.id}>
                <MrbRow gap={2} className="mrb-fill-x">
                  <MrbCol xs="fill">
                    <MrbTypography variant="h3">{item.content}</MrbTypography>
                    <MrbTypography variant="secondary">
                      Column: {item.column?.name}
                    </MrbTypography>
                    <MrbRow horizontal="right" gap={1}>
                      <MrbButton variant="primary" onClick={() => handleEditNote(item.id)}>
                        Edit
                      </MrbButton>
                      <MrbButton variant="danger" onClick={() => handleDeleteNote(item.id)}>
                        Delete
                      </MrbButton>
                    </MrbRow>
                  </MrbCol>
                </MrbRow>
              </MrbList.Item>
            ))}
          </MrbList>
          <MrbRow>
            {Array.from({ length: 6 }, (_, index) => (
              <MrbCol key={index} xs={2}>
                <MrbButton onClick={() => handleAddNote(String(index + 1))}>
                  Add Note
                </MrbButton>
              </MrbCol>
            ))}
          </MrbRow>
        </>
      )}
    </PageLayout>
  )
}