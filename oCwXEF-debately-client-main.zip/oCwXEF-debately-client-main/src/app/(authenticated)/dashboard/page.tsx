'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbGrid, MrbGridItem, MrbLoader, MrbRow, MrbTypography } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Note, NoteApi } from '@/domain/note'
import { Speech, SpeechApi } from '@/domain/speech'
import { Timer, TimerApi } from '@/domain/timer'
import { Teleprompter, TeleprompterApi } from '@/domain/teleprompter'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function DashboardPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [userData, setUserData] = useState<Partial<User>>({})

  useEffect(() => {
    if (userId) {
      UserApi.findOne(userId, { includes: ['notes', 'speechs', 'timers'] })
        .then((data) => {
          setUserData(data)
          setLoading(false)
        })
        .catch((error) => {
          toast.error('Failed to fetch user data.')
          setLoading(false)
        })
    }
  }, [userId])

  const handleEditNote = (noteId: string) => {
    router.push(`/flow-notes/${noteId}`)
  }

  const handleDeleteNote = (noteId: string) => {
    // Logic for deleting a note
  }

  const handleEditSpeech = (speechId: string) => {
    router.push(`/speeches/${speechId}`)
  }

  const handleStartTeleprompter = (speechId: string) => {
    router.push(`/teleprompter/${speechId}`)
  }

  const handleEditTimer = (timerId: string) => {
    router.push(`/timers/${timerId}`)
  }

  const handleStartTimer = (timerId: string) => {
    // Logic for starting a timer
  }

  const navigateTo = (path: string) => {
    router.push(path)
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          <MrbGrid gap={2}>
            {userData.notes?.map((note) => (
              <MrbGridItem xs={12} sm={6} md={4} key={note.id}>
                <MrbCard size="medium">
                  <MrbCard.Body>
                    <MrbTypography variant="primary">{note.content}</MrbTypography>
                  </MrbCard.Body>
                  <MrbCard.Footer>
                    <MrbButton onClick={() => handleEditNote(note.id)}>Edit</MrbButton>
                    <MrbButton variant="danger" onClick={() => handleDeleteNote(note.id)}>Delete</MrbButton>
                  </MrbCard.Footer>
                </MrbCard>
              </MrbGridItem>
            ))}

            {userData.speechs?.map((speech) => (
              <MrbGridItem xs={12} sm={6} md={4} key={speech.id}>
                <MrbCard size="medium">
                  <MrbCard.Body>
                    <MrbTypography variant="primary">{speech.content}</MrbTypography>
                  </MrbCard.Body>
                  <MrbCard.Footer>
                    <MrbButton onClick={() => handleStartTeleprompter(speech.id)}>Start Teleprompter</MrbButton>
                    <MrbButton onClick={() => handleEditSpeech(speech.id)}>Edit</MrbButton>
                  </MrbCard.Footer>
                </MrbCard>
              </MrbGridItem>
            ))}

            {userData.timers?.map((timer) => (
              <MrbGridItem xs={12} sm={6} md={4} key={timer.id}>
                <MrbCard size="medium">
                  <MrbCard.Body>
                    <MrbTypography variant="primary">{`Timer: ${timer.duration} seconds`}</MrbTypography>
                  </MrbCard.Body>
                  <MrbCard.Footer>
                    <MrbButton onClick={() => handleStartTimer(timer.id)}>Start</MrbButton>
                    <MrbButton onClick={() => handleEditTimer(timer.id)}>Edit</MrbButton>
                  </MrbCard.Footer>
                </MrbCard>
              </MrbGridItem>
            ))}
          </MrbGrid>

          <MrbRow horizontal="center" gap={2}>
            <MrbButton onClick={() => navigateTo('/flow-notes')}>Manage Flow Notes</MrbButton>
            <MrbButton onClick={() => navigateTo('/speeches')}>Manage Speeches</MrbButton>
            <MrbButton onClick={() => navigateTo('/timers')}>Manage Timers</MrbButton>
          </MrbRow>
        </>
      )}
    </PageLayout>
  )
}