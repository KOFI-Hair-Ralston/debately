'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbDescription, MrbButton, MrbEmptyState, MrbLink, MrbLoader, MrbRow, MrbTypography, MrbDescriptionList } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Speech, SpeechApi } from '@/domain/speech'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function SpeechesPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [items, setItems] = useState<Speech[]>([])

  useEffect(() => {
    if (userId) {
      SpeechApi.findManyByUserId(userId)
        .then(speeches => {
          setItems(speeches)
          setLoading(false)
        })
        .catch(error => {
          toast.error('Failed to fetch speeches.')
          setLoading(false)
        })
    }
  }, [userId])

  const handleEdit = (speechId: string) => {
    router.push(`/speeches/${speechId}`)
  }

  const handleDelete = async (speechId: string) => {
    await SpeechApi.deleteOne(speechId)
    setItems(items.filter(item => item.id !== speechId))
    toast.success('Speech deleted successfully.')
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          {items.length === 0 && (
            <MrbEmptyState>
              You don't have any speeches yet!
              <MrbLink to="/speeches/new" variant="primary">
                Create your first speech
              </MrbLink>
            </MrbEmptyState>
          )}

          {items.map(item => (
            <MrbCard key={item.id} size="full-width" className="m-1">
              <MrbCard.Header>
                <MrbTypography variant="h3">{item.type}</MrbTypography>
              </MrbCard.Header>
              <MrbCard.Body>
                <MrbDescriptionList orientation="horizontal">
                  <MrbDescription>
                    <MrbDescription.Label>Type</MrbDescription.Label>
                    <MrbDescription.Value>{item.type}</MrbDescription.Value>
                  </MrbDescription>
                  <MrbDescription>
                    <MrbDescription.Label>Created</MrbDescription.Label>
                    <MrbDescription.Value>
                      {DateLibrary.toHuman(item.dateCreated)}
                    </MrbDescription.Value>
                  </MrbDescription>
                </MrbDescriptionList>
              </MrbCard.Body>
              <MrbCard.Footer>
                <MrbRow horizontal="right" gap={1}>
                  <MrbButton variant="primary" onClick={() => handleEdit(item.id)}>
                    Edit
                  </MrbButton>
                  <MrbButton variant="danger" onClick={() => handleDelete(item.id)}>
                    Delete
                  </MrbButton>
                </MrbRow>
              </MrbCard.Footer>
            </MrbCard>
          ))}
        </>
      )}
    </PageLayout>
  )
}