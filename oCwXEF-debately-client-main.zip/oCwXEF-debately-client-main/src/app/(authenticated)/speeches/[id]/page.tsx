'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbButton, MrbLoader, MrbRow, MrbForm } from '@/designSystem'
import { Speech, SpeechApi } from '@/domain/speech'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function EditSpeechPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id
  const [isLoading, setLoading] = useState<boolean>(true)
  const [speech, setSpeech] = useState<Speech | null>(null)

  useEffect(() => {
    async function fetchSpeech() {
      try {
        const speechData = await SpeechApi.findOne(params.id)
        setSpeech(speechData)
      } catch (error) {
        toast.error('Failed to load speech data.')
      } finally {
        setLoading(false)
      }
    }

    fetchSpeech()
  }, [params.id])

  const handleSave = async (values: any) => {
    try {
      await SpeechApi.updateOne(params.id, { content: values.content })
      toast.success('Speech updated successfully.')
      router.push('/speeches')
    } catch (error) {
      toast.error('Failed to update speech.')
    }
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && speech && (
        <MrbForm
          defaultValues={{ content: speech.content }}
          onSubmit={handleSave}
          inputs={[
            {
              key: 'content',
              type: 'textarea',
              label: 'Edit Speech',
            },
          ]}
        >
          <MrbButton type="submit">Save</MrbButton>
        </MrbForm>
      )}

      <MrbRow horizontal="center" gap={1}>
        <MrbButton onClick={() => router.push('/speeches')}>Back to Speeches</MrbButton>
      </MrbRow>
    </PageLayout>
  )
}