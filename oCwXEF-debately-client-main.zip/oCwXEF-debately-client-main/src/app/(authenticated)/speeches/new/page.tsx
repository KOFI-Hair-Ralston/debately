'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbTypography, MrbForm } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Speech, SpeechApi } from '@/domain/speech'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function NewSpeechPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(false)

  const handleSubmit = async (values) => {
    if (!userId) {
      toast.error('User ID is not available.')
      return
    }

    setLoading(true)
    try {
      await SpeechApi.createOneByUserId(userId, values)
      toast.success('Speech successfully created.')
      router.push('/speeches')
    } catch (error) {
      toast.error('Failed to create speech.')
    }
    setLoading(false)
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1">New Speech</MrbTypography>
      <MrbCard size="full-width" className="m-2">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={[
              {
                key: 'type',
                type: 'text',
                label: 'Type',
              },
              {
                key: 'content',
                type: 'textarea',
                label: 'Content',
              },
            ]}
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Create
            </MrbButton>
          </MrbForm>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}