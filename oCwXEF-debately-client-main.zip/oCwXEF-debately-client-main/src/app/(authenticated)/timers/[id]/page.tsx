'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbLoader, MrbRow, MrbTypography, MrbForm } from '@/designSystem'
import { Timer, TimerApi } from '@/domain/timer'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function EditTimerPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [item, setItem] = useState<Timer | null>(null)

  useEffect(() => {
    const fetchTimer = async () => {
      try {
        const timerData = await TimerApi.findOne(params.id)
        setItem(timerData)
      } catch (error) {
        toast.error('Failed to fetch timer details.')
      } finally {
        setLoading(false)
      }
    }

    if (params.id) {
      fetchTimer()
    }
  }, [params.id])

  const handleSubmit = async (values: { duration: number }) => {
    try {
      await TimerApi.updateOne(params.id, { duration: values.duration })
      toast.success('Timer updated successfully.')
      router.push('/timers')
    } catch (error) {
      toast.error('Failed to update timer.')
    }
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && item && (
        <MrbCard>
          <MrbCard.Body>
            <MrbTypography variant="h3">
              Edit Timer
            </MrbTypography>
            <MrbForm
              onSubmit={handleSubmit}
              inputs={[
                {
                  key: 'duration',
                  type: 'number',
                  label: 'Duration (minutes)',
                },
              ]}
              defaultValues={{ duration: item.duration }}
            >
              <MrbButton type="submit">Save Changes</MrbButton>
            </MrbForm>
          </MrbCard.Body>
          <MrbCard.Footer>
            <MrbRow horizontal="right" gap={1}>
              <MrbButton onClick={() => router.push('/timers')}>
                Cancel
              </MrbButton>
            </MrbRow>
          </MrbCard.Footer>
        </MrbCard>
      )}
    </PageLayout>
  )
}