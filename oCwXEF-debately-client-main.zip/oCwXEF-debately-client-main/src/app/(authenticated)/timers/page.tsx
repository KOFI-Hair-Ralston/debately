'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbDescription, MrbButton, MrbCol, MrbEmptyState, MrbList, MrbLoader, MrbRow, MrbDescriptionList, MrbModal } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Timer, TimerApi } from '@/domain/timer'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function TimersPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [items, setItems] = useState<Timer[]>([])
  const [modalOpen, setModalOpen] = useState<boolean>(false)
  const [selectedTimerId, setSelectedTimerId] = useState<string | null>(null)

  useEffect(() => {
    if (userId) {
      TimerApi.findManyByUserId(userId)
        .then((timers) => {
          setItems(timers)
        })
        .catch((error) => {
          toast.error('Failed to fetch timers')
        })
        .finally(() => {
          setLoading(false)
        })
    }
  }, [userId])

  const handleDeleteTimer = (timerId: string) => {
    TimerApi.deleteOne(timerId)
      .then(() => {
        setItems(items.filter((item) => item.id !== timerId))
        toast.success('Timer deleted successfully')
      })
      .catch(() => {
        toast.error('Failed to delete timer')
      })
      .finally(() => {
        setModalOpen(false)
      })
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          <MrbRow horizontal="right" className="mb-4">
            <MrbButton onClick={() => router.push('/timers/new')}>
              Create New Timer
            </MrbButton>
          </MrbRow>

          {items?.length === 0 ? (
            <MrbEmptyState>
              You don't have any timers yet!
            </MrbEmptyState>
          ) : (
            <MrbList divider={true}>
              {items?.map((timer) => (
                <MrbList.Item key={timer.id}>
                  <MrbRow gap={2} className="mrb-fill-x">
                    <MrbCol xs="fill">
                      <MrbDescriptionList orientation="horizontal">
                        <MrbDescription>
                          <MrbDescription.Label>Type</MrbDescription.Label>
                          <MrbDescription.Value>{timer.type}</MrbDescription.Value>
                        </MrbDescription>
                        <MrbDescription>
                          <MrbDescription.Label>Duration</MrbDescription.Label>
                          <MrbDescription.Value>{timer.duration} minutes</MrbDescription.Value>
                        </MrbDescription>
                      </MrbDescriptionList>
                    </MrbCol>
                    <MrbCol horizontal="right">
                      <MrbButton variant="primary" onClick={() => router.push(`/timers/${timer.id}`)}>
                        Edit
                      </MrbButton>
                      <MrbButton variant="danger" onClick={() => {
                        setSelectedTimerId(timer.id)
                        setModalOpen(true)
                      }}>
                        Delete
                      </MrbButton>
                    </MrbCol>
                  </MrbRow>
                </MrbList.Item>
              ))}
            </MrbList>
          )}
        </>
      )}

      <MrbModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        header="Delete Timer"
        footer={
          <>
            <MrbButton variant="default" onClick={() => setModalOpen(false)}>
              Cancel
            </MrbButton>
            <MrbButton variant="danger" onClick={() => handleDeleteTimer(selectedTimerId!)}>
              Delete
            </MrbButton>
          </>
        }
      >
        Are you sure you want to delete this timer?
      </MrbModal>
    </PageLayout>
  )
}