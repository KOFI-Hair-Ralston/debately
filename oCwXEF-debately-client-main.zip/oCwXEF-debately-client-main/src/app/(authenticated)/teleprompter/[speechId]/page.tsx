'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbLoader, MrbRow, MrbTypography } from '@/designSystem'
import { Speech, SpeechApi } from '@/domain/speech'

import { Teleprompter, TeleprompterApi } from '@/domain/teleprompter'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function TeleprompterPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [item, setItem] = useState<Speech | null>(null)

  useEffect(() => {
    async function fetchSpeech() {
      try {
        const speechId = params.speechId
        if (!speechId) {
          toast.error('Speech ID is missing')
          router.push('/speeches')
          return
        }

        const speech = await SpeechApi.findOne(speechId)
        setItem(speech)
      } catch (error) {
        toast.error('Failed to fetch speech content')
      } finally {
        setLoading(false)
      }
    }

    fetchSpeech()
  }, [params.speechId, router])

  // Teleprompter controls state
  const [isScrolling, setIsScrolling] = useState(false)
  const [scrollSpeed, setScrollSpeed] = useState(1)

  const handleStart = () => setIsScrolling(true)
  const handlePause = () => setIsScrolling(false)
  const handleSpeedChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const speed = Number(event.target.value)
    setScrollSpeed(speed)
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && item && (
        <MrbCard>
          <MrbCard.Body>
            {/* Teleprompter display area */}
            <div className="teleprompter-content" style={{ overflowY: isScrolling ? 'auto' : 'hidden', scrollBehavior: 'smooth' }}>
              <MrbTypography variant="primary">{item.content}</MrbTypography>
            </div>
          </MrbCard.Body>
          <MrbCard.Footer>
            {/* Teleprompter controls */}
            <MrbRow horizontal="center" gap={1}>
              <MrbButton onClick={handleStart} disabled={isScrolling}>Start</MrbButton>
              <MrbButton onClick={handlePause} disabled={!isScrolling}>Pause</MrbButton>
              <label htmlFor="speed">Speed:</label>
              <input type="range" id="speed" name="speed" min="0.5" max="3" step="0.1" value={scrollSpeed} onChange={handleSpeedChange} />
            </MrbRow>
          </MrbCard.Footer>
        </MrbCard>
      )}
    </PageLayout>
  )
}