

import { Speech } from "../speech"

export class Teleprompter {

id: string

speed: number

speechId: string

speech?: Speech

dateCreated: string

dateDeleted: string

dateUpdated: string

}
