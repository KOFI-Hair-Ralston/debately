import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Teleprompter } from './teleprompter.model'

export namespace TeleprompterApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Teleprompter>,
  ): Promise<Teleprompter[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/teleprompters${buildOptions}`)
  }

  export function findOne(
    teleprompterId: string,
    queryOptions?: ApiHelper.QueryOptions<Teleprompter>,
  ): Promise<Teleprompter> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/teleprompters/${teleprompterId}${buildOptions}`,
    )
  }

  export function createOne(
    teleprompter: Partial<Teleprompter>,
  ): Promise<Teleprompter> {
    return HttpService.api.post(`/v1/teleprompters`, teleprompter)
  }

  export function updateOne(
    teleprompterId: string,
    values: Partial<Teleprompter>,
  ): Promise<Teleprompter> {
    return HttpService.api.patch(
      `/v1/teleprompters/${teleprompterId}`,
      values,
    )
  }

  export function deleteOne(teleprompterId: string): Promise<void> {
    return HttpService.api.delete(`/v1/teleprompters/${teleprompterId}`)
  }

export function findManyBySpeechId(
    speechId: string,
    queryOptions?: ApiHelper.QueryOptions<Teleprompter>,
  ): Promise<Teleprompter[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/speechs/speech/${speechId}/teleprompters${buildOptions}`,
    )
  }

  export function createOneBySpeechId(
    speechId: string,
    values: Partial<Teleprompter>,
  ): Promise<Teleprompter> {
    return HttpService.api.post(
      `/v1/speechs/speech/${speechId}/teleprompters`,
      values,
    )
  }

}
