import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Note } from './note.model'

export namespace NoteApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Note>,
  ): Promise<Note[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/notes${buildOptions}`)
  }

  export function findOne(
    noteId: string,
    queryOptions?: ApiHelper.QueryOptions<Note>,
  ): Promise<Note> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/notes/${noteId}${buildOptions}`,
    )
  }

  export function createOne(
    note: Partial<Note>,
  ): Promise<Note> {
    return HttpService.api.post(`/v1/notes`, note)
  }

  export function updateOne(
    noteId: string,
    values: Partial<Note>,
  ): Promise<Note> {
    return HttpService.api.patch(
      `/v1/notes/${noteId}`,
      values,
    )
  }

  export function deleteOne(noteId: string): Promise<void> {
    return HttpService.api.delete(`/v1/notes/${noteId}`)
  }

export function findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Note>,
  ): Promise<Note[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/notes${buildOptions}`,
    )
  }

  export function createOneByUserId(
    userId: string,
    values: Partial<Note>,
  ): Promise<Note> {
    return HttpService.api.post(
      `/v1/users/user/${userId}/notes`,
      values,
    )
  }

export function findManyByColumnId(
    columnId: string,
    queryOptions?: ApiHelper.QueryOptions<Note>,
  ): Promise<Note[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/columnDatas/column/${columnId}/notes${buildOptions}`,
    )
  }

  export function createOneByColumnId(
    columnId: string,
    values: Partial<Note>,
  ): Promise<Note> {
    return HttpService.api.post(
      `/v1/columnDatas/column/${columnId}/notes`,
      values,
    )
  }

}
