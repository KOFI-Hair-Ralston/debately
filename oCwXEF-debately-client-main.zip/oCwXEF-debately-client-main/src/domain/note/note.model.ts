

import { User } from "../user"

import { ColumnData } from "../columnData"

export class Note {

id: string

content: string

position: number

userId: string

user?: User

columnId: string

column?: ColumnData

dateCreated: string

dateDeleted: string

dateUpdated: string

}
