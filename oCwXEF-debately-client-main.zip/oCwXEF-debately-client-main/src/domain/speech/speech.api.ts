import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Speech } from './speech.model'

export namespace SpeechApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Speech>,
  ): Promise<Speech[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/speechs${buildOptions}`)
  }

  export function findOne(
    speechId: string,
    queryOptions?: ApiHelper.QueryOptions<Speech>,
  ): Promise<Speech> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/speechs/${speechId}${buildOptions}`,
    )
  }

  export function createOne(
    speech: Partial<Speech>,
  ): Promise<Speech> {
    return HttpService.api.post(`/v1/speechs`, speech)
  }

  export function updateOne(
    speechId: string,
    values: Partial<Speech>,
  ): Promise<Speech> {
    return HttpService.api.patch(
      `/v1/speechs/${speechId}`,
      values,
    )
  }

  export function deleteOne(speechId: string): Promise<void> {
    return HttpService.api.delete(`/v1/speechs/${speechId}`)
  }

export function findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Speech>,
  ): Promise<Speech[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/speechs${buildOptions}`,
    )
  }

  export function createOneByUserId(
    userId: string,
    values: Partial<Speech>,
  ): Promise<Speech> {
    return HttpService.api.post(
      `/v1/users/user/${userId}/speechs`,
      values,
    )
  }

}
