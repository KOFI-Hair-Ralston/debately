

import { User } from "../user"

import { Teleprompter } from "../teleprompter"

export class Speech {

id: string

type: string

content: string

userId: string

user?: User

dateCreated: string

dateDeleted: string

dateUpdated: string

teleprompters?: Teleprompter[]

}
