import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { ColumnData } from './columnData.model'

export namespace ColumnDataApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<ColumnData>,
  ): Promise<ColumnData[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/columnDatas${buildOptions}`)
  }

  export function findOne(
    columnDataId: string,
    queryOptions?: ApiHelper.QueryOptions<ColumnData>,
  ): Promise<ColumnData> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/columnDatas/${columnDataId}${buildOptions}`,
    )
  }

  export function createOne(
    columnData: Partial<ColumnData>,
  ): Promise<ColumnData> {
    return HttpService.api.post(`/v1/columnDatas`, columnData)
  }

  export function updateOne(
    columnDataId: string,
    values: Partial<ColumnData>,
  ): Promise<ColumnData> {
    return HttpService.api.patch(
      `/v1/columnDatas/${columnDataId}`,
      values,
    )
  }

  export function deleteOne(columnDataId: string): Promise<void> {
    return HttpService.api.delete(`/v1/columnDatas/${columnDataId}`)
  }

}
