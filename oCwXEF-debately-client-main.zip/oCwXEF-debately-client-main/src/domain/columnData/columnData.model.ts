

import { Note } from "../note"

export class ColumnData {

id: string

name: string

dateCreated: string

dateDeleted: string

dateUpdated: string

notes?: Note[]

}
