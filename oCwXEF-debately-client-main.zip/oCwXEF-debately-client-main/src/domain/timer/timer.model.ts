

import { User } from "../user"

export class Timer {

id: string

type: string

duration: number

userId: string

user?: User

dateCreated: string

dateDeleted: string

dateUpdated: string

}
