import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Timer } from './timer.model'

export namespace TimerApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Timer>,
  ): Promise<Timer[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/timers${buildOptions}`)
  }

  export function findOne(
    timerId: string,
    queryOptions?: ApiHelper.QueryOptions<Timer>,
  ): Promise<Timer> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/timers/${timerId}${buildOptions}`,
    )
  }

  export function createOne(
    timer: Partial<Timer>,
  ): Promise<Timer> {
    return HttpService.api.post(`/v1/timers`, timer)
  }

  export function updateOne(
    timerId: string,
    values: Partial<Timer>,
  ): Promise<Timer> {
    return HttpService.api.patch(
      `/v1/timers/${timerId}`,
      values,
    )
  }

  export function deleteOne(timerId: string): Promise<void> {
    return HttpService.api.delete(`/v1/timers/${timerId}`)
  }

export function findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Timer>,
  ): Promise<Timer[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/timers${buildOptions}`,
    )
  }

  export function createOneByUserId(
    userId: string,
    values: Partial<Timer>,
  ): Promise<Timer> {
    return HttpService.api.post(
      `/v1/users/user/${userId}/timers`,
      values,
    )
  }

}
